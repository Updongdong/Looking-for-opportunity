# -*- coding: utf-8 -*-
"""
Created on Sun May 24 16:27:20 2020

@author: sudong
"""

import numpy as np
from PIL import Image

def means_filter(input_image, filter_size):
    '''
    均值滤波器
    :param input_image: 输入图像
    :param filter_size: 滤波器大小
    :return: 输出图像

    注：此实现滤波器大小必须为奇数且 >= 3
    '''
    input_image_cp = np.copy(input_image)  # 输入图像的副本

    filter_template = np.ones((filter_size, filter_size))  # 空间滤波器模板

    pad_num = int((filter_size - 1) / 2)  # 输入图像需要填充的尺寸

    input_image_cp = np.pad(input_image_cp, (pad_num, pad_num), mode="constant", constant_values=0)  # 填充输入图像

    m, n = input_image_cp.shape  # 获取填充后的输入图像的大小

    output_image = np.copy(input_image_cp)  # 输出图像

    # 空间滤波
    for i in range(pad_num, m - pad_num):
        for j in range(pad_num, n - pad_num):
            output_image[i, j] = np.sum(filter_template * input_image_cp[i - pad_num:i + pad_num + 1, j - pad_num:j + pad_num + 1]) / (filter_size ** 2)

    output_image = output_image[pad_num:m - pad_num, pad_num:n - pad_num]  # 裁剪

    return output_image

def strech(img):
    arr_mean = np.mean(img)
    k = 127.5/arr_mean
    img = img*k
    # img = limit(img)
    return img


def location(image):
    a = 10
    filt = 1
    height, width = image.shape
    image[0:10,:]=0
    image[height-10:height,:]=0
    image[:,0:10]=0
    image[:,width-10:width]=0
    bound = np.zeros((height, width), dtype=np.float)       
    for i in range(1,height-2,2):
        for j in range(1,width-2,2):
            for m in range(2):
                for n in range(2):
                    filt = filt*image[i+m,j+n]
            for m in range(2):
                for n in range(2):
                    image[i+m,j+n] = filt
            filt = 1
    image_new = image.clip(0, 255)
    image_new = np.rint(image_new).astype('uint8')
    b = np.argwhere(image_new>0)
    
    for i in range(b.shape[0]):
        y = b[i,1]
        x = b[i,0]
        bound[x-a:x+a,y-a]=255
        bound[x-a:x+a,y+a]=255
        bound[x-a,y-a:y+a]=255
        bound[x+a,y-a:y+a]=255
    return bound,x,y
 

if __name__=='__main__':
    img1 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\016644_rec.jpg").convert('L')
    img2 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\0128.jpg").convert('L')
    img1 = strech(img1)
    img2 = strech(img2)
    img1 = means_filter(img1,3)
    img2 = means_filter(img2,3)
    img = np.true_divide(img2,img1)
    img[img<2.5] = 0
    img = img1*img
    # img = convolve(img)
    img[img<35] = 0
    bounding,x,y = location(img)
    bounding = bounding+img1
    bounding = bounding.clip(0,255)
    print(x,y)
    r = Image.fromarray(bounding).convert('L')
    g = Image.fromarray(img1).convert('L')
    b = Image.fromarray(img1).convert('L')
    img = Image.merge('RGB',(r,g,b))
    # img= Image.fromarray(img)
    img.convert('RGB').save('F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\result.jpg')