# -*- coding: utf-8 -*-
"""
Created on Sun May 24 18:19:23 2020

@author: sudong
"""
# -*- coding: utf-8 -*-
"""
Created on Sun May 24 10:44:36 2020

@author: sudong
"""
from PIL import Image
import numpy as np

def deviation(img,dmin = 0,dmax = 255,K = 2.5):
    arr_std = np.std(img,ddof=1)
    arr_mean = np.mean(img)
    ucMax = arr_mean+K*arr_std
    ucMin = arr_mean-K*arr_std
    k = (dmax - dmin) / (ucMax - ucMin)
    b = (ucMax*dmin - ucMin*dmax) / (ucMax - ucMin)
    dev_img = k*img + b
    dev_img = limit(dev_img)
    return dev_img

def strech(img):
    arr_mean = np.mean(img)
    k = 127.5/arr_mean
    img = img*k
    # img = limit(img)
    return img

def limit(x,sigma=0.7):
    # a = 2
    b = 127.5
    s = b*sigma
    y = b*(np.exp(1/s*(x-b))- np.exp(-1/s*(x-b)))/(np.exp(1/s*(x-b)) + np.exp(-1/s*(x-b)))+b
    return y




def corre(image1,image2):
    min_ = 1
    height, width = image1.shape
    a = 10
    image1[0:10,:]=0
    image1[height-10:height,:]=0
    image1[:,0:10]=0
    image1[:,width-10:width]=0
    image2[0:10,:]=0
    image2[height-10:height,:]=0
    image2[:,0:10]=0
    image2[:,width-10:width]=0
    image_new = np.ones((height, width), dtype=np.float)
    bound = np.zeros((height, width), dtype=np.float)
    for i in range(2,height-2,2):
        for j in range(2,width-2,2):
            im1 = []
            im2 = []
            im1.append(image1[i-2:i+2,j-2:j+2])
            im2.append(image2[i-2:i+2,j-2:j+2]) 
            im1 = np.array(im1)
            im2 = np.array(im2)
            up = np.mean(im1*im2)
            arr_mean1 = np.mean(im1*im1)
            arr_mean2 = np.mean(im2*im2)
            low = pow(arr_mean1*arr_mean2,0.5)
            cor = up/low
            if cor<min_:
                min_=cor
            image_new[i,j]=cor
    b = np.argwhere(image_new<(min_+0.08)) #保函零值           
    for i in range(b.shape[0]):
        y = b[i,1]
        x = b[i,0]
        bound[x-a:x+a,y-a]=255
        bound[x-a:x+a,y+a]=255
        bound[x-a,y-a:y+a]=255
        bound[x+a,y-a:y+a]=255
    return bound,x,y

 
    

if __name__=='__main__':
    img1 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case1\\rectified\\0128_re.jpg").convert('L')
    img2 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case1\\rectified\\011765_re.jpg").convert('L')
    img1 = strech(img1)
    img2 = strech(img2)
    img = img1+0
    bounding,x,y = corre(img1,img2)
    bounding = bounding+img
    bounding = bounding.clip(0,255)
    print(x,y)
    r = Image.fromarray(bounding).convert('L')
    g = Image.fromarray(img).convert('L')
    b = Image.fromarray(img).convert('L')
    img = Image.merge('RGB',(r,g,b))
    img.convert('RGB').save('F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case1\\rectified\\result.jpg')
