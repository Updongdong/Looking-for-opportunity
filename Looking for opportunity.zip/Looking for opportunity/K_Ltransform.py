# -*- coding: utf-8 -*-
"""
Created on Sun May 24 20:57:34 2020

@author: sudong
"""

import numpy as np
from PIL import Image

def strech(img):
    arr_mean = np.mean(img)
    k = 127.5/arr_mean
    img = img*k
    # img = limit(img)
    return img


def k_l(img):
    img = np.asanyarray(img)
    h,w = img.shape
    m = np.mean(img)
    n = np.ones((h,w))
    m = n*m
    c = np.cov(img,bias=True)
    lamda,phi = np.linalg.eig(c)
    sort_lamda = -np.sort(-lamda)
    sort_index = np.argsort(-lamda)
    Selected_phi2 = np.concatenate((phi[:,sort_index[0]].reshape(h,1),
                               phi[:,sort_index[1]].reshape(h,1),
                               phi[:,sort_index[2]].reshape(h,1),
                               phi[:,sort_index[3]].reshape(h,1),
                               phi[:,sort_index[4]].reshape(h,1),
                               phi[:,sort_index[5]].reshape(h,1),
                               phi[:,sort_index[6]].reshape(h,1),
                               phi[:,sort_index[7]].reshape(h,1)),axis=1)
    omega = np.dot(Selected_phi2.T,img)
    img = np.dot(Selected_phi2,omega)+m
    return img

def k_l_c(img1,img2):
    return np.abs(img1 - img2)


if __name__=='__main__':
    img1 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\016644_rec.jpg").convert('L')
    img2 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\0128.jpg").convert('L')    
    img1 = k_l(img1)
    img2 = k_l(img2)
    img1 = strech(img1)
    img2 = strech(img2)
    img1 = np.abs(img1)
    # img = k_l_c(img1,img2)
    # img[img<2.5] = 0
    # img = img1*img
    # # img = convolve(img)
    # img[img<35] = 0
    # bounding,x,y = location(img)
    # bounding = bounding+img1
    # bounding = bounding.clip(0,255)
    # print(x,y)
    # r = Image.fromarray(bounding).convert('L')
    # g = Image.fromarray(img1).convert('L')
    # b = Image.fromarray(img1).convert('L')
    # img = Image.merge('RGB',(r,g,b))
    img= Image.fromarray(img1)
    img.convert('L').save('F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\result1.jpg')