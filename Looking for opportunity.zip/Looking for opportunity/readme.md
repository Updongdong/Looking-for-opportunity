beijingcha：就是差分法
bizhi：就是比值法
K_Ltransform：KL变换
matchshift：shift匹配
match_post_process:匹配后的裁剪，去除无效数据
xiangguanxishu：相关系数方法
meanshift：meanshift分割