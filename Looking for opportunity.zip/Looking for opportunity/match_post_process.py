# -*- coding: utf-8 -*-
"""
Created on Mon May 25 12:44:47 2020

@author: sudong
"""
import numpy as np
from PIL import Image

def post_(img1,img2):
    a = 0
    b = 0
    im1 = np.asanyarray(img1)
    im2 = np.asanyarray(img2)
    h,w  =im2.shape
    for i in range(h):
        if im2[i,0] >0:
            a = i
            break
    for i in range(w):
        if im2[h-1,i] ==0:
            b = i
            break
    box = np.array([0,a,b,h-1])
    img1 = img1.crop(box)
    img2 = img2.crop(box)
   
    return img1,img2

if __name__=='__main__':
    img1 = Image.open("F:/python_code/1.jpg").convert('L')
    img2 = Image.open("F:/python_code/3.jpg").convert('L')   

    img1,img2 = post_(img1,img2)
    img1.convert('RGB').save("F:/python_code/4.jpg")
    img2.convert('RGB').save("F:/python_code/5.jpg")