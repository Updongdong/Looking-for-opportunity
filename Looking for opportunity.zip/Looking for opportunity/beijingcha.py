# -*- coding: utf-8 -*-
"""
Created on Sun May 24 10:44:36 2020

@author: sudong
"""
from PIL import Image
import numpy as np

def deviation(img,dmin = 0,dmax = 255,K = 2.5):
    arr_std = np.std(img,ddof=1)
    arr_mean = np.mean(img)
    ucMax = arr_mean+K*arr_std
    ucMin = arr_mean-K*arr_std
    k = (dmax - dmin) / (ucMax - ucMin)
    b = (ucMax*dmin - ucMin*dmax) / (ucMax - ucMin)
    dev_img = k*img + b
    dev_img = limit(dev_img)
    return dev_img

def strech(img):
    arr_mean = np.mean(img)
    k = 127.5/arr_mean
    img = img*k
    # img = limit(img)
    return img

def limit(x,sigma=0.7):
    # a = 2
    b = 127.5
    s = b*sigma
    y = b*(np.exp(1/s*(x-b))- np.exp(-1/s*(x-b)))/(np.exp(1/s*(x-b)) + np.exp(-1/s*(x-b)))+b
    return y

def convolve(image):
    filt = 1
    height, width = image.shape
    image[0:10,:]=0
    image[height-10:height,:]=0
    image[:,0:10]=0
    image[:,width-10:width]=0
    for i in range(0,height-2,2):
        for j in range(0,width-2,2):
            for m in range(2):
                for n in range(2):
                    filt = filt*image[i+m,j+n]
            for m in range(2):
                for n in range(2):
                    image[i+m,j+n] = filt
            filt = 1
    image_new = image.clip(0, 255)
    image_new = np.rint(image_new).astype('uint8')
    return image_new

def location(image):
    a = 10
    filt = 1
    height, width = image.shape
    bound = np.zeros((height, width), dtype=np.float)       
    for i in range(1,height-2,2):
        for j in range(1,width-2,2):
            for m in range(2):
                for n in range(2):
                    filt = filt*image[i+m,j+n]
            for m in range(2):
                for n in range(2):
                    image[i+m,j+n] = filt
            filt = 1
    image_new = image.clip(0, 255)
    image_new = np.rint(image_new).astype('uint8')
    b = np.argwhere(image_new>0)
    
    for i in range(b.shape[0]):
        y = b[i,1]
        x = b[i,0]
        bound[x-a:x+a,y-a]=255
        bound[x-a:x+a,y+a]=255
        bound[x-a,y-a:y+a]=255
        bound[x+a,y-a:y+a]=255
    return bound,x,y
 
    

if __name__=='__main__':
    img2 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\result1.jpg").convert('L')
    img1 = Image.open("F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\result2.jpg").convert('L')
    img1 = strech(img1)
    img2 = strech(img2)
    img = np.abs(img2 - img1)
    img[img<35] = 0
    img = convolve(img)
    img[img<35] = 0
    bounding,x,y = location(img)
    bounding = bounding+img1
    bounding = bounding.clip(0,255)
    print(x,y)
    r = Image.fromarray(bounding).convert('L')
    g = Image.fromarray(img1).convert('L')
    b = Image.fromarray(img1).convert('L')
    img = Image.merge('RGB',(r,g,b))
    img.convert('RGB').save('F:\\航天航空课程视频\\作业\\寻找机遇号\\Opportunity\\case3\\rectified\\result.jpg')